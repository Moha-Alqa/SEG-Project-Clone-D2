package group26_HMS.pms.domain.common

interface DomainEvent {
}