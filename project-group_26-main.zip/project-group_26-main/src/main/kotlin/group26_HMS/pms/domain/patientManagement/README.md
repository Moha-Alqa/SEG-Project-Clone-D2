## Patient Registration and Management Sub-Domain

- Core
- Functional requirements: F1, F2, F9, F11
- Focuses on the registration and ongoing management of patients within the hospital system