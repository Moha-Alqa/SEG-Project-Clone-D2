package group26_HMS.pms.domain.prescriptionManagement.services

class placeholder { //delete and implement your own with correct name
}