## User Registeration and Management sub-domain

- Support
- Functional requirements: F10.1, F12, F13
- User Accounts
- Includes functionalities for registering new patients, updating their information, and maintaining their records
- Maintaining system security and access control
- Ensure that only authorized personnel can access and modify various aspects of the system