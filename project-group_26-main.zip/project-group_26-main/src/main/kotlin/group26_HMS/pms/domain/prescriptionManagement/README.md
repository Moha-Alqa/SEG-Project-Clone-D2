## Prescription Management Sub-Domain

- Support
- Functional requirements: F8, F8.1
- Supports patient care by allowing doctors to prescribe medications to their patients
- Encompasses functionalities related to prescription creation and management