package group26_HMS.pms.domain.patientManagement.entities

class PatientKin (
    val fullName:String,
    val relationshipToPatient: String,
    val address: Address,
    val phoneNum:String
) {
}