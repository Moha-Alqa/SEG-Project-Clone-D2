# SEG3102 Project - Wellmeadows Hospital Management System (PMS)

## Group Number
Group 26

## Team Members

| Name               | Student Number |
|--------------------|----------------|
| Oscar Li           | 300248450      |
| Allen Mei          | 300238743      |
| Mohammad Alqahtani | 300249098      |
| Tori Wu            | 300231361      |
